#Hypothesis Testing
## Load the Dataset
library(readxl)

# 2 sample t Test
#######cutlets.csv#########
cutlets <- read.csv("G:/practical data science/Assignments/Hypothesis Testing/Cutlets.csv")
View(cutlets)
colnames(cutlets) <- c("InterestRateWaiver", "StandardPromotion")
# Changing column names
View(cutlets)
attach(cutlets)
#Normality Test
shapiro.test(InterestRateWaiver)
# p-value = 0.2246 > 0.05 so p high null fly => It follows normal distribution

shapiro.test(StandardPromotion)
# p-value = 0.1916 >0.05 so p high null fly => It follows normal distribution
# Variance test
var.test(InterestRateWaiver, StandardPromotion)
# p-value = 0.653 > 0.05 so p high null fly => Equal variances
# 2 sample t Test assuming equal variances
t.test(InterestRateWaiver, StandardPromotion, alternative = "two.sided", conf.level = 0.95, var.equal = T)
# alternative = "two.sided" means we are checking for equal and unequal means
# null Hypothesis -> Equal means
# Alternate Hypothesis -> Unequal Hypothesis
# p-value = 0.02523 < 0.05 accept alternate Hypothesis unequal means

?t.test
t.test(InterestRateWaiver, StandardPromotion, alternative = "greater")

# alternative = "greater means true difference is greater than 0
# Null Hypothesis -> (InterestRateWaiver-StandardPromotion) < 0
# Alternative Hypothesis -> (StandardPromotion - InterestRateWaiver) > 0
# p-value = 0.01211 < 0.05 => p low null go => accept alternate hypothesis

# Conclusion:
# InterestRateWaiver better promotion than StandardPromotion

