# Hypothesis Testing

# Load the Dataset
library(readxl)
# Load the data: Buyer Ratio

BuyerRatio <- read.csv("G:/practical data science/Assignments/Hypothesis Testing/BuyerRatio.csv") 
View(BuyerRatio)
attach(BuyerRatio)
table1 <- table(Person)
table1

table2 <- table(East)
table2

table3 <- table(North)
table3
table4 <- table(West)
table4
table5 <- table(South)
table5

?prop.test
prop.test(x = c(58,152),n = c(480,740), conf.level = 0.95, alternative = "two.sided")
# two.sided -> means checking for equal proportions of Adults and children under purchased
# p-value = 6.261e-05 < 0.05 accept alternate hypothesis i.e.
# Unequal proportions 

prop.test(x = c(58,152), n = c(480,740), conf.level = 0.95, alternative = "greater")

