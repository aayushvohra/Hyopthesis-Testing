# Load the data: customer order form
library("readxl")
customerorder <- read.csv("G:/practical data science/Assignments/Hypothesis Testing/CustomerOrderform.csv") 
View(customerorder)

attach(customerorder)
table(CustomerOrderform["Error Free"], CustomerOrderform["Phillippines","Indonesia","Malta","India"])
table
chisq.test(table(CustomerOrderform["Error Free"], CustomerOrderform["Phillippines","Indonesia","Malta","India"]))

# p-value = 0.6315 > 0.05  => Accept null hypothesis
# => All countries have equal proportions 

# All Proportions are equal 
