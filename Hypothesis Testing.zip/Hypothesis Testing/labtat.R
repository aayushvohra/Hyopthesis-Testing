# Hypothesis Testing

# Load the Dataset
library(readxl)
######## LabTAT.csv data ##########
labtat <- read.csv("G:/practical data science/Assignments/Hypothesis Testing/lab_tat_updated.csv")

View(labtat)
attach(labtat)
# Normality test
shapiro.test(`Laboratory_1`)
shapiro.test(`Laboratory_2`)
shapiro.test(`Laboratory_3`)
shapiro.test(`Laboratory_4`)

# Variance test
var.test(`Laboratory_1`, `Laboratory_2`)
var.test(`Laboratory_2`, `Laboratory_3`)
var.test(`Laboratory_3`, `Laboratory_4`)
var.test(`Laboratory_4`, `Laboratory_1`)

Stacked_Data <- stack(labtat)
?stack
View(Stacked_Data)

attach(Stacked_Data)
colnames(Stacked_Data)
labtat_results <- aov(values ~ ind, data = Stacked_Data)
summary(labtat_results)

# p-value = 0.104 > 0.05 accept null hypothesis
# 3 suppliers transaction times are equal

