#########cutlets#######

import pandas as pd
import scipy
from scipy import stats
cutlets=pd.read_csv("G:/practical data science/Assignments/Hypothesis Testing/Cutlets.csv")

cutlets.columns="UnitA" ,"UnitB"

#Normality Test
stats.shapiro(cutlets.UnitA)
stats.shapiro(cutlets.UnitB)

#Variance Test
scipy.stats.levene(cutlets.UnitA,cutlets.UnitB)

#2 Sample T test
scipy.stats.ttest_ind(cutlets.UnitA, cutlets.UnitB)

##########LABTAT###########

lab=pd.read_csv("G:/practical data science/Assignments/Hypothesis Testing/lab_tat_updated.csv")

#Normality Test
stats.shapiro(lab.Laboratory_1)
stats.shapiro(lab.Laboratory_2)
stats.shapiro(lab.Laboratory_3)
stats.shapiro(lab.Laboratory_4)

#Variance Test
scipy.stats.levene(lab.Laboratory_1,lab.Laboratory_2)
scipy.stats.levene(lab.Laboratory_2,lab.Laboratory_3)
scipy.stats.levene(lab.Laboratory_3,lab.Laboratory_4)
scipy.stats.levene(lab.Laboratory_4,lab.Laboratory_1)
scipy.stats.levene(lab.Laboratory_3,lab.Laboratory_1)
scipy.stats.levene(lab.Laboratory_4,lab.Laboratory_2)

#One- Way Anova Test
F,p=stats.f_oneway(lab.Laboratory_1,lab.Laboratory_2,lab.Laboratory_3,lab.Laboratory_4)
p

##############Buyer Ratio#############
buyer=pd.read_csv("G:/practical data science/Assignments/Hypothesis Testing/BuyerRatio.csv")

import numpy as np

from statsmodels.stats.proportion import proportions_ztest

count=np.array([50,435])
total=np.array([393,4073])

stats,pval = proportions_ztest(count,total,alternative='two-sided')
print(pval)

count2=np.array([142,1532])
total=np.array([393,4073])

stats,pval = proportions_ztest(count2,total,alternative='two-sided')
print(pval)

count3=np.array([131,1356])
total=np.array([393,4073])

stats,pval = proportions_ztest(count3,total,alternative='two-sided')
print(pval)

count4=np.array([70,750])
total=np.array([393,4073])

stats,pval = proportions_ztest(count4,total,alternative='two-sided')
print(pval)

######################CustomerOrderForm################

cust=pd.read_csv("G:/practical data science/Assignments/Hypothesis Testing/CustomerOrderform.csv")

count = pd.crosstab(cust["Defective"], cust["Country"])
count
Chisquares_results = scipy.stats.chi2_contingency(count)

Chi_square = [['Test Statistic', 'p-value'], [Chisquares_results[0], Chisquares_results[1]]]
Chi_square
count = pd.crosstab(cust["Defective"], cust["Country"])
count
Chisquares_results = scipy.stats.chi2_contingency(count)

Chi_square = [['Test Statistic', 'p-value'], [Chisquares_results[0], Chisquares_results[1]]]
Chi_square

############Fantaloons###############

fantaloons=pd.read_csv("G:/practical data science/Assignments/Hypothesis Testing/Fantaloons.csv")

#Weekdays
cnt=np.array([287,113])
ttl=np.array([520,280])

stats,pval = proportions_ztest(cnt, ttl,alternative='two-sided')
print(pval)

#alternative- greater
stats,pval=proportions_ztest(cnt, ttl,alternative = 'larger')
print(pval)


#Weekends
cnt1=np.array([233,167])
ttl1=np.array([520,280])

stats,pval = proportions_ztest(cnt1, ttl1,alternative='two-sided')
print(pval)

#alternative- greater
stats,pval=proportions_ztest(cnt1, ttl1,alternative = 'larger')
print(pval)
